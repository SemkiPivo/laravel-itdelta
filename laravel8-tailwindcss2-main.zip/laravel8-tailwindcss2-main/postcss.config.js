module.export = {
    plugins: {
        tailwindcss: {},
        autoprefixer: {},
    },
}